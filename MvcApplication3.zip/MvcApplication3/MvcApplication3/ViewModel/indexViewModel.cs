﻿using MvcApplication3.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web; 
namespace MvcApplication3.ViewModel
{
    public class indexViewModel
    {
        public Category newCategory { get; set; }

        public List<Category> CategoryList { get; set; }
    }
}