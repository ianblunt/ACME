﻿using MvcApplication3.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcApplication3.ViewModel
{
    public class CategoryViewModel
    {
        public List<StockItem> CategoryStockList { get; set; }
        public Category MainCategoryItem { get; set; }

        #region CONSTRUCTORS

        public Boolean AnyStock
        {
            get
            {
                try
                {
                    if (this.CategoryStockList.Count() > 0)
                    {
                        return true;
                    }
                }
                catch
                {
                }
                return false;
            }
        }
        

        #endregion CONSTRUCTORS
    }
}