﻿Hi.

I hope that this test is acceptable for you. I know that part of the test was to create a standalone 'plug and play' system.

I haven't been able to accomplish that - in order to have something to show you, I've done it in the quickest way I know - that is 
an ASP.NET MVC project.

This means that you'll have to run it through Visual Studio in order to run it - just run it as a normal project. It ought to start at 
the main page which lists categories that are available.

in >Models>DataContext.cs is the main function library for the project - I've created the connections to Linnworks web API and used the controls mentioned.

So I have the functions to get a list of categories, delete, update the categories.  I created the the custom query as mentioned on the technical test.
However, I used another custom query to get a list of stock per Category. Although not mentioned in the Document, I thought it was a useful function instead.

If you want to see the function calls to the Web API, this takes place in the >Models>DataContext.cs. These are called from >Controllers>HomeControllers.

I've used a link to a javascript front end to create some nice sortable data table displays.

I hope that doing it this way doesn't affect my application, I have just used the quickest method I know to at least present you with something.

Thanks!
Ian
