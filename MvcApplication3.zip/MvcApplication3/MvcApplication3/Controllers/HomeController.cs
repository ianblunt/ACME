﻿
using MvcApplication3.Models;
using MvcApplication3.ViewModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace MvcApplication3.Controllers
{
    public class HomeController : Controller
    {

        public DataContext context = new DataContext();

        public ActionResult Index()
        {
            var vm = new indexViewModel();
            vm.CategoryList = this.context.getCategoryList(); 
            return View(vm);
        }
       
        [HttpPost]
        public ActionResult Index(indexViewModel item)
        {
            //create NEW Category
            this.context.createNewCategory(item.newCategory.CategoryName);

            var vm = new indexViewModel();
            vm.CategoryList = this.context.getCategoryList();
            vm.newCategory = new Category();
            vm.newCategory.CategoryName = string.Empty;
            return View(vm);
        }

        public ActionResult DeleteCategory(string ID)
        {
            this.context.deleteCategory(ID);
            return RedirectToAction("Index");
        }

        public ActionResult Category(string ID)
        {
            var vm = new CategoryViewModel();
            vm.MainCategoryItem = this.context.getCategoryList().Where(c => c.CategoryID == ID).FirstOrDefault();
            vm.CategoryStockList = this.context.getStockDetailsListByCategory(ID);
            return View(vm);
        }
        [HttpPost]
        public ActionResult Category(CategoryViewModel item)
        {
            this.context.updateCategory(item.MainCategoryItem.CategoryID, item.MainCategoryItem.CategoryName);
            var vm = new CategoryViewModel();
            vm.MainCategoryItem = this.context.getCategoryList().Where(c => c.CategoryID == item.MainCategoryItem.CategoryID).FirstOrDefault();
            vm.CategoryStockList = this.context.getStockDetailsListByCategory(item.MainCategoryItem.CategoryID);
            return View(vm);
         
        }
   
    }
}
