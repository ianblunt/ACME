﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Xml;
using System.Xml.Linq;

namespace MvcApplication3.Models
{
    //DataContext - central data Functionality

    public class DataContext
    {
        public string TokenID = "76284bac-4794-40b7-885a-fb0e6e87891e";
        public string mainInventoryUrl = @"https://eu-ext.linnworks.net//api/Inventory";
        public string mainDashboardUrl = @"https://eu-ext.linnworks.net//api/DashBoards";
        #region CATEGORIES

        /// <summary>
        /// Get a full category List
        /// </summary>
        /// <returns></returns>
        public List<Category> getCategoryList()
        {
            var url = string.Format("{0}/GetCategories?token={1}", this.mainInventoryUrl, this.TokenID);
            
                var wc = this.buildStandardWebClient();

                string result = @wc.DownloadString(url);

                JArray blogPostArray = JArray.Parse(result);
                var newList = new List<Category>();

                foreach (var item in blogPostArray.Children())
                {
                    newList.Add(
                        new Category
                        {
                            CategoryID = (string)item["CategoryId"],
                            CategoryName = (string)item["CategoryName"]
                        });
                     
                }
                return newList;
        }
        /// <summary>
        /// Create New Category
        /// </summary>
        /// <param name="CategoryName"></param>
        public void createNewCategory(string CategoryName)
        {
            var url = string.Format("{0}/CreateCategory?token={1}&categoryName={2}", this.mainInventoryUrl, this.TokenID, CategoryName);

            var wc = this.buildStandardWebClient();

            string result = @wc.DownloadString(url);
        }
        /// <summary>
        /// Delete Existing Category
        /// </summary>
        /// <param name="CategoryId"></param>
        public void deleteCategory(string CategoryId)
        {
            var url = string.Format("{0}/DeleteCategoryById?token={1}&categoryID={2}", this.mainInventoryUrl, this.TokenID, CategoryId);

            var wc = this.buildStandardWebClient();

            string result = @wc.DownloadString(url);
        }

        public List<Category> getStockCountByCategory()
        { 
            var url = this.mainDashboardUrl + "/ExecuteCustomScriptQuery?token=" + this.TokenID + "&script=" +"Select p.CategoryID,Count(*) AS STOCK From StockItem AS S INNER JOIN ProductCategories  AS P on P.CategoryID = S.CategoryId GROUP BY P.CategoryId";
            var wc = this.buildStandardWebClient();

            string result = @wc.DownloadString(url);
            var newList = new List<Category>();

            
            dynamic dynJson = JsonConvert.DeserializeObject(result);
            foreach (var item in dynJson.Results)
            {
                var test = item.CategoryID;
                newList.Add(
                       new Category
                       {
                           CategoryID = (string)item["CategoryID"],
                           StockNumber =(int)item["STOCK"]
                       });
            }

            return newList;
        }

        public List<StockItem> getStockDetailsListByCategory(string CategoryID)
        {
            var newList = new List<StockItem>();
            var url = this.mainDashboardUrl + "/ExecuteCustomScriptQuery?token=" + this.TokenID + "&script=" +"Select * From StockItem AS  S WHERE  S.CategoryId ='" + CategoryID + "'";
            var wc = this.buildStandardWebClient();

            string result = @wc.DownloadString(url);
            dynamic dynJson = JsonConvert.DeserializeObject(result);
            
            foreach (var item in dynJson.Results)
            {
                newList.Add(new StockItem
                {
                    CategoryID = (Guid)item["CategoryId"],
                    StockID = (Guid)item["pkStockItemID"],
                    ItemTitle = (string)item["ItemTitle"],
                    ItemNumber = (string)item["ItemNumber"],
                     Description = (string)item["ItemDescription"],
                    CreatedDate = (DateTime)item["CreationDate"],
                    RetailPrice = (Decimal)item["RetailPrice"],
                    PurchasePrice = (Decimal)item["PurchasePrice"]
                });
            }

            return newList;
             
        }

        public void updateCategory(string CategoryId, string CategoryName)
        {  
            var url = this.mainInventoryUrl + "/UpdateCategory?token=" + this.TokenID + "&category={'CategoryId':'" + CategoryId + "','CategoryName':'" + CategoryName + "'}";
 
            var wc = this.buildStandardWebClient();

            string result = @wc.DownloadString(url);

        }


       

       
        #endregion CATEGORIES

        #region UTILITY

        public WebClient buildStandardWebClient()
        {
            var wc = new WebClient();

            wc.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");
            wc.Headers.Add("Accept", "application/json");

            return wc;
        }
        #endregion UTILITY
    }
}