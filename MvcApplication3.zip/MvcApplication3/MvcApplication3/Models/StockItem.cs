﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcApplication3.Models
{
    public class StockItem
    {
        public Guid StockID { get; set; }
        public Guid CategoryID { get; set; }
        public String ItemTitle { get; set; }
        public string ItemNumber { get; set; }
        public string Description { get; set; }
        public Decimal PurchasePrice { get; set; }
        public Decimal RetailPrice { get; set; }
        public DateTime CreatedDate { get; set; }

    }
}