﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MvcApplication3.Models
{
    public class Category
    {
        public string CategoryID { get; set; }
         [Required(ErrorMessage = "You must enter a Category Name.")]
        public string CategoryName { get; set; }
        public int StockNumber { get; set; }
    }
}